#!/bin/bash
. /etc/openvpn/script/config.sh


##Authentication
#user_id=$(mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -sN -e "select user_id from user where user_id = '$username' AND user_pass = '$password' AND user_enable=1 AND user_start_date != user_end_date AND TO_DAYS(now()) >= TO_DAYS(user_start_date) AND (TO_DAYS(now()) <= TO_DAYS(user_end_date) OR user_end_date='0000-00-00')")
 #user_id=$(mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -sN -e "SELECT users.user_name FROM users WHERE users.user_name='$username' AND users.user_pass='$password' AND users.is_active=1 AND users.is_validated=1 AND users.regdate != users.code AND TO_DAYS(now()) >= TO_DAYS(users.regdate) AND (TO_DAYS(now()) <= TO_DAYS(users.code))  ")                                                       
 user_id=$(mysql -h$HOST -P$PORT -u$USER -p$PASS $DB -sN -e "SELECT users.user_name FROM users WHERE users.user_name='$username' AND users.user_pass='$password' AND users.is_validated=1 AND users.frozen=0 AND  users.duration > 0 ")                                                       

##Check user
[ "$user_id" != '' ] && [ "$user_id" = "$username" ] && echo "user : $username" && echo 'authentication ok.' && exit 0 || echo 'authentication failed.'; exit 1