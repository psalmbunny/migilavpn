#!/bin/bash
##Dababase Server
HOST='31.22.4.247'
USER='migilase_migila'
PASS='20migila19'
DB='migilase_migila'
PORT='3306'