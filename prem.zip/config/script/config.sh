#!/bin/bash
##Dababase Server
HOST='31.22.4.247'
USER='migila'
PASS='migila2019'
DB='migila2019'
PORT='3306'